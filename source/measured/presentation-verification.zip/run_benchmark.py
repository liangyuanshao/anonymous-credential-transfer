import datetime as dt
import hashlib
import json
from pathlib import Path
import platform
import subprocess
from zipfile import ZipFile

root = Path.cwd()
previous = json.loads((root / 'previous-environment.json').read_text(encoding='utf-8'))
archives = root / 'measured-source.zip'
with ZipFile(archives) as z:
    z.extractall()
    files = {name: hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
assert files['tests/legacy_ours.hpp'] == previous['source_sha256']['src/ours.hpp']
for name in ('src/core.hpp', 'src/group_arithmetic.hpp', 'src/oom_windows.hpp', 'parameters/type-f.param'):
    assert files[name] == previous['source_sha256'][name]
assert files['src/ours.hpp'] != previous['source_sha256']['src/ours.hpp']

base = root.parent
pbc = base / 'attribute-scale-20261108/vendor/pbc-1.0.0'
gmp = base / 'attribute-scale-20261108/dependencies/gmp/usr'
library = base / 'utilization-10000-20261110.3cBxAn/build/libpbc_local.a'
binary = root / 'presentation_verify_window_bench'
raw = root / 'raw_timings.csv'
command = ['g++', '-O3', '-DNDEBUG', '-std=gnu++17', '-Isrc', '-Ibaselines',
           f'-I{pbc / "include"}', f'-I{pbc}', f'-I{gmp / "include/x86_64-linux-gnu"}',
           'tests/presentation_verify_window_bench.cpp', '-o', str(binary), str(library), '-lcrypto',
           str(gmp / 'lib/x86_64-linux-gnu/libgmp.a'), '-lm']
subprocess.run(command, check=True)
runner = ['taskset', '-c', '9', str(binary), 'parameters/type-f.param']
subprocess.run(runner + ['1', '60'], check=True, stdout=subprocess.DEVNULL)
start = dt.datetime.now(dt.timezone.utc).isoformat()
with raw.open('x', encoding='utf-8') as out:
    subprocess.run(runner + ['100'], stdout=out, check=True)
cpu = next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
memory = int(Path('/proc/meminfo').read_text().splitlines()[0].split()[1]) * 1024
manifest = dict(
    complete=True, started_utc=start, completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    hardware={'cpu':cpu, 'total_memory_bytes':memory}, platform=platform.platform(),
    compiler=subprocess.check_output(['g++','--version'], text=True).splitlines()[0],
    build='-O3 -DNDEBUG -std=gnu++17', libraries={'PBC':'1.0.0','GMP':'6.3.0'}, affinity=[9],
    repetitions=100, warmups=3, d=2, ell=[64], attribute_counts=sorted([*range(4,65,4),58,59]),
    paired_attribute_counts=[56,58,59,60,64], source_sha256=files,
    binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),
    previous_raw_sha256=previous['raw_sha256'],
    scope='OTAC ell=64 verification including the candidate registration check, proof verification and spent tag insertion. Issuance, sampling, proof generation, state copies and wire decoding are outside timed intervals. Old and new verification at paired attribute counts use the same proof, and alternate execution order.')
(root/'environment.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')