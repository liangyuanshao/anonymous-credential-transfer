"""Build the three PGFPlots figures for the rewritten performance chapter."""

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZipFile

import numpy as np

from figure_support import COLORS, LABELS, MARKERS, OPS, ROOT, TITLES
from figure_support import dat, plot_table, render, sha, write_tex
from result_io import load_csv, save_csv


PROJECT = ROOT.parent
SCHEMES = ("OTAC", "ACL", "CY22")
ATTRIBUTES = (2, 3, 4, 5)
CANDIDATES = (16, 32, 64, 128, 256, 512, 1024)
GROUP_FIELDS = ("experiment", "scheme", "profile", "operation", "ell", "n", "d")
CORE_SOURCES = (
    "src/ours.hpp", "src/core.hpp", "src/group_arithmetic.hpp",
    "src/oom_fixed.hpp", "src/oom_windows.hpp", "parameters/type-f.param",
)
COMPARABLE_FIELDS = (
    "platform", "architecture", "hardware", "compiler", "build", "libraries",
    "arithmetic_backend", "single_threaded", "clock", "timing", "repetitions", "warmups",
)
OPS_BY_PANEL = (("show", "verify"), ("transfer", "verify_transfer"))


def source_path(path):
    try:
        return path.resolve().relative_to(PROJECT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def verified_batch(directory):
    meta_path = directory / "environment.json"
    raw_path = directory / "raw_timings.csv"
    summary_path = directory / "summary.csv"
    env = json.loads(meta_path.read_text(encoding="utf-8"))
    if not (env["complete"] and env["source_unchanged"] and env["binary_unchanged"]):
        raise ValueError(f"Incomplete or unstable measurement batch: {directory}")
    digest = sha(raw_path)
    if env["raw_sha256"] != digest:
        raise ValueError(f"Raw timing digest mismatch: {raw_path}")
    if env["repetitions"] != 100 or env["warmups"] != 3:
        raise ValueError(f"Unexpected repetitions or warmups: {directory}")
    groups = defaultdict(list)
    for row in load_csv(raw_path):
        groups[tuple(row[field] for field in GROUP_FIELDS)].append(row)
    summary = {tuple(row[field] for field in GROUP_FIELDS): row
               for row in load_csv(summary_path)}
    if set(summary) != set(groups):
        raise ValueError(f"Summary and raw series differ: {directory}")
    index = {}
    for number, key in enumerate(sorted(groups)):
        _, scheme, _, op, ell, n, d = key
        workload = (scheme, op, int(ell), int(n), int(d))
        if workload in index:
            raise ValueError(f"Ambiguous measured workload: {workload}")
        index[workload] = (number, key)

    def point(scheme, op, ell, n, d):
        number, key = index[(scheme, op, ell, n, d)]
        records = groups[key]
        repetitions = env["repetitions"]
        if sorted(int(row["repetition"]) for row in records) != list(range(repetitions)):
            raise ValueError(f"Missing or duplicate repetitions: {key}")
        times = np.asarray([float(row["ms"]) for row in records])
        if not np.all(np.isfinite(times)) or np.any(times <= 0):
            raise ValueError(f"Invalid timing: {key}")
        complete = int(not (scheme == "CY22" and op in OPS[:2]))
        if {int(row["operation_complete"]) for row in records} != {complete}:
            raise ValueError(f"Operation coverage mismatch: {key}")
        rng = np.random.default_rng(20261107 + number)
        bootstrap = np.median(rng.choice(times, (10_000, repetitions)), axis=1)
        low, high = np.percentile(bootstrap, (2.5, 97.5))
        median = float(np.median(times))
        observed = (median, float(low), float(high))
        saved = tuple(float(summary[key][field])
                      for field in ("median_ms", "ci95_low_ms", "ci95_high_ms"))
        if not all(math.isclose(a, b, rel_tol=1e-12) for a, b in zip(observed, saved)):
            raise ValueError(f"Median or confidence interval differs from stored summary: {key}")
        return dict(
            scheme=scheme, operation=op, n=n, d=d, ell=ell,
            ell_applies=int(scheme == "OTAC"), profile=key[2], complete=complete,
            median=median, low=float(low), high=float(high), repetitions=repetitions,
            source_csv=source_path(raw_path), source_sha256=digest,
        )

    audit = dict(raw_csv=source_path(raw_path), raw_sha256=digest,
                 environment=source_path(meta_path), environment_sha256=sha(meta_path),
                 summary_sha256=sha(summary_path), start_utc=env["recorded_at_utc"],
                 finish_utc=env["completed_at_utc"], series=len(groups))
    return env, point, audit


def timed_otac_source(directory, env):
    with ZipFile(directory / "measured-source.zip") as archive:
        for name in (*CORE_SOURCES, "src/comparison.cpp"):
            content = archive.read(name)
            if hashlib.sha256(content).hexdigest() != env["source_sha256"][name]:
                raise ValueError(f"Archived source digest mismatch: {name}")
        comparison = archive.read("src/comparison.cpp").decode("utf-8")
    case = comparison.split("static void run_case(", 1)[1]
    timed_body = case.split(" const auto attrs=", 1)[1]
    for separator in ("\n  if(baselines)baseline_case", "\n  baseline_case"):
        if separator in timed_body:
            return timed_body.split(separator, 1)[0]
    raise ValueError("Cannot isolate the OTAC portion of the archived benchmark")


def verify_independent_batch(current, historical, current_env, historical_env):
    for key in COMPARABLE_FIELDS:
        if current_env[key] != historical_env[key]:
            raise ValueError(f"Historical environment differs on {key}")
    for name in CORE_SOURCES:
        if current_env["source_sha256"][name] != historical_env["source_sha256"][name]:
            raise ValueError(f"Historical OTAC implementation differs: {name}")
    if timed_otac_source(current, current_env) != timed_otac_source(historical, historical_env):
        raise ValueError("Historical timed OTAC block differs")
    if current_env["raw_sha256"] == historical_env["raw_sha256"]:
        raise ValueError("Candidate scaling must come from a distinct measurement batch")


def curve(folder, name, rows, x, color, mark, dash):
    path = dat(folder, name, [(row[x], row) for row in rows])
    style = (f"color={color},{dash},mark={mark},"
             f"mark options={{solid,fill={color},draw={color}}},mark size=1.4pt,line width=1pt,err,"
             r"error bars/error mark options={rotate=90,mark size=2.5pt,line width=.45pt}")
    return plot_table(path, style)


def ticks(values):
    return ",".join(f"{value:g}" for value in values)


def total_attributes_axis():
    return (r"paper,xmin=1.78,xmax=5.22,xtick={2,3,4,5},xticklabels={2,3,4,5},"
            r"xlabel={Total attributes, $n$}")


def panel_title(index, title):
    return rf"title={{\textbf{{{chr(97+index)}}}\quad {title}}}"


def note(text):
    return (r"\node[anchor=south east,font=\scriptsize,yshift=22pt] at (group c2r1.north east) "
            f"{{{text}}};\n")


def plot_comparison(folder, point):
    name = "figure_1_algorithm_costs"
    body = (r"\begin{groupplot}[group style={group size=2 by 2,horizontal sep=16mm,vertical sep=20mm},"
            + total_attributes_axis()
            + r",width=89.5mm,height=56mm,ymode=log,log ticks with fixed point,"
              r"minor y tick num=0,ylabel={Time (ms, log scale)}]"+"\n")
    source = []
    dashes = ("solid", "densely dashed", "densely dotted")
    for panel, (op, title) in enumerate(zip(OPS, TITLES)):
        series = {scheme: [point(scheme, op, 64, n, 2) for n in ATTRIBUTES]
                  for scheme in SCHEMES}
        points = [row for rows in series.values() for row in rows]
        source.extend(points)
        ymin = min(row["low"] for row in points)*.8
        ymax = max(row["high"] for row in points)*1.23
        ytick = [m * 10.**e
                 for e in range(math.floor(math.log10(ymin)), math.ceil(math.log10(ymax))+1)
                 for m in (1, 2, 5) if ymin <= m * 10.**e <= ymax]
        axis_ticks = f",ytick={{{ticks(ytick)}}}" if len(ytick) >= 2 else ""
        legend = (r",legend style={at={(0,1.22)},anchor=south west,legend columns=3}"
                  if panel == 0 else "")
        body += (rf"\nextgroupplot[{panel_title(panel, title)},"
                 f"ymin={ymin:.12g},ymax={ymax:.12g}{axis_ticks}{legend}]\n")
        for (scheme, rows), dash in zip(series.items(), dashes):
            body += curve(folder, f"comparison_{op}_{scheme}", rows, "n",
                          COLORS[scheme], MARKERS[scheme], dash)
            if panel == 0:
                label = "CY22 (issuance core)" if scheme == "CY22" else LABELS[scheme]
                body += rf"\addlegendentry{{{label}}}"+"\n"
    body += "\\end{groupplot}\n"
    body += note(r"$d=2$, $\ell=64$ (this work)")
    write_tex(folder, name, body)
    save_csv(folder / "figure_1_source_data.csv", source)
    return len(source)


def plot_otac_sweep(folder, point, *, by_candidates):
    if by_candidates:
        name = "figure_2_candidate_scale"
        configurations = [(ell, 2, 2) for ell in CANDIDATES]
        xticklabels = ",".join(r"\textbf{64}" if ell == 64 else str(ell) for ell in CANDIDATES)
        axis = (r"paper,xmode=log,log basis x=2,xmin=14.8,xmax=1100,"
                rf"xtick={{{ticks(CANDIDATES)}}},xticklabels={{{xticklabels}}},"
                r"xlabel={Candidate set size, $\ell$}")
        x = "ell"
        workload = r"$n=d=2$ (separate batch)"
    else:
        name = "figure_3_attribute_scale"
        configurations = [(64, n, 2) for n in ATTRIBUTES]
        axis = total_attributes_axis()
        x = "n"
        workload = r"$d=2$, $\ell=64$"
    ops = [op for panel in OPS_BY_PANEL for op in panel]
    series = {op: [point("OTAC", op, *config) for config in configurations] for op in ops}
    source = [row for rows in series.values() for row in rows]
    ymax = max(row["high"] for row in source)*1.16
    body = (r"\begin{groupplot}[group style={group size=2 by 1,horizontal sep=16mm},"
            + axis + rf",width=89.5mm,height=59mm,ymin=0,ymax={ymax:.12g}]"+"\n")
    styles = (("ours", "*", "solid", "Generation"),
              ("acl", "square*", "densely dashed", "Verification"))
    for panel, (operations, title) in enumerate(zip(OPS_BY_PANEL, ("Consumption", "Transfer"))):
        legend = (r",legend style={at={(0,1.20)},anchor=south west,legend columns=2}"
                  if panel == 0 else "")
        body += rf"\nextgroupplot[{panel_title(panel, title)}{legend}]"+"\n"
        for op, (color, mark, dash, label) in zip(operations, styles):
            body += curve(folder, f"{x}_{op}", series[op], x, color, mark, dash)
            if panel == 0:
                body += rf"\addlegendentry{{{label}}}"+"\n"
    body += "\\end{groupplot}\n"
    body += note(workload)
    write_tex(folder, name, body)
    figure = 2 if by_candidates else 3
    save_csv(folder / f"figure_{figure}_source_data.csv", source)
    return len(source)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current", type=Path, default=ROOT / "results/current")
    parser.add_argument("--candidate-sweep", type=Path,
                        default=PROJECT / "archive/performance-variable-ell-20261107/results/current")
    parser.add_argument("--output", type=Path, default=PROJECT / "中文稿/assets/performance-rewrite")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--revision", default="rewrite-v1")
    args = parser.parse_args()
    current_env, current_point, current_audit = verified_batch(args.current)
    historical_env, historical_point, historical_audit = verified_batch(args.candidate_sweep)
    verify_independent_batch(args.current, args.candidate_sweep, current_env, historical_env)

    args.output.mkdir(parents=True, exist_ok=True)
    counts = {
        "figure_1": plot_comparison(args.output, current_point),
        "figure_2": plot_otac_sweep(args.output, historical_point, by_candidates=True),
        "figure_3": plot_otac_sweep(args.output, current_point, by_candidates=False),
    }
    audit = dict(
        renderer="XeLaTeX/PGFPlots", archetype="quantitative grid", point_counts=counts,
        panels={"figure_1": "Four measured operation costs across total attributes",
                "figure_2": "Independent OTAC consumption and transfer candidate-size sweep",
                "figure_3": "OTAC consumption and transfer at fixed candidate size"},
        current_batch=current_audit, historical_candidate_batch=historical_audit,
        matched_environment_fields=list(COMPARABLE_FIELDS), matched_otac_sources=list(CORE_SOURCES),
        matched_otac_timed_block=True, batches_spliced=False,
        baseline_coverage={"CY22_issuance": "honest-party core",
                           "OIP-U-Prove": "no comparable numerical series in these batches"},
        bootstrap_resamples=10_000, intervals="percentile bootstrap 95%",
        source_verification="Recomputed every plotted median and interval from raw measurements",
        plot_generator_sha256=sha(Path(__file__)),
    )
    (args.output / "data_audit.json").write_text(json.dumps(audit, indent=2)+"\n", encoding="utf-8")
    if not args.prepare_only:
        render(args.output, args.revision)
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
