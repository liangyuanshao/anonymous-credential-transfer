"""Copy the measured PGFPlots figures into the Chinese manuscript."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess

from figure_support import ROOT, sha

STEMS=('figure_1_algorithm_costs','figure_2_anonymity_set','figure_3_attributes')
UTILIZATION_STEM='figure_4_issuance_utilization'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=ROOT/'results/current')
    parser.add_argument('--figures-dir',type=Path,default=ROOT/'figures/current')
    parser.add_argument('--utilization-dir',type=Path,default=ROOT/'results/utilization')
    parser.add_argument('--figure-suffix',default='_current')
    args=parser.parse_args()
    data,fig,utilization=args.directory,args.figures_dir,args.utilization_dir
    assert json.loads((data/'qa.json').read_text(encoding='utf-8'))['passed']
    utilization_meta=json.loads((utilization/'environment.json').read_text(encoding='utf-8'))
    assert utilization_meta['complete']
    assert sha(utilization/'raw_timings.csv')==utilization_meta['raw_sha256']
    for folder,stem in [(fig,s) for s in STEMS]+[(utilization,UTILIZATION_STEM)]:
        for ext in ('pdf','png'):
            assert (folder/(stem+'.'+ext)).is_file(),(folder,stem,ext)

    dest=ROOT.parent/'中文稿/assets/performance'
    workspace=ROOT.parent.resolve()
    assert dest.resolve().is_relative_to(workspace)
    assert all(c.isalnum() or c in '_-' for c in args.figure_suffix)
    dest.mkdir(parents=True,exist_ok=True)
    records=[]
    def copy_figure(source,stem,aliases):
        for ext in ('pdf','png'):
            src=source/(stem+'.'+ext)
            for name in aliases:
                path=dest/(name+'.'+ext)
                shutil.copy2(src,path)
                assert sha(src)==sha(path)
                records.append(dict(file=path.name,source=str(src.resolve()),sha256=sha(path)))

    for stem in STEMS:
        copy_figure(fig,stem,dict.fromkeys((stem,stem+args.figure_suffix)))
        svg=dest/(stem+'.svg')
        subprocess.run(['pdftocairo','-svg',str(fig/(stem+'.pdf')),str(svg)],check=True)
        assert svg.stat().st_size>1000
        records.append(dict(file=svg.name,source='pdftocairo conversion of current PDF',sha256=sha(svg)))
    copy_figure(utilization,UTILIZATION_STEM,(UTILIZATION_STEM,))
    result=dict(revision=data.name,assets=str(dest),
                replaced_figures=len(STEMS)+1,assets_copied_or_converted=records,
                manuscript_image_suffix=args.figure_suffix,
                utilization_raw_sha256=utilization_meta['raw_sha256'])
    (data/'asset_integration.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(replaced_figures=len(STEMS)+1,assets=str(dest)),ensure_ascii=False))


if __name__=='__main__':main()
