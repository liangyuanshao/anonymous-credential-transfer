"""Synchronize only the Chinese performance chapter with completed measurements."""
from pathlib import Path
import hashlib
import json
import statistics
from result_io import load_csv

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'results/current'
DOC=ROOT.parent/'中文稿/08_性能分析与实验评估.md'


def main():
    qa=json.loads((DATA/'qa.json').read_text(encoding='utf-8'))
    assert qa['passed'] and qa['repetitions']==100 and qa['rows']==12600
    old=DOC.read_bytes();text=old.decode('utf-8-sig')
    assert '表 5：签发交互比较。' in text and '## 8.2 计算开销' in text
    rounds=text.split('表 5：签发交互比较。',1)[1].split('## 8.2 计算开销',1)[0]
    prefix=text.split('## 8.1 通信开销',1)[0]
    prefix=prefix.replace('本节从通信开销和计算开销分析本方案。','本节从通信开销和计算开销分析本方案，并测量新增转让算法。')
    prefix=prefix.replace('二元 OoM[20]和共同开口证明完成一次性属性认证。','二元 OoM[20]和共同开口证明完成一次性属性认证及同属性转让。')
    prefix=prefix.replace('并测量新增转让算法。','并报告转让开销。')
    prefix=prefix.replace('两方案的注册开口证明均采用 Fiat–Shamir 非交互形式','本文签发申请和 ACL 注册中的开口证明均采用 Fiat–Shamir 非交互形式')
    if '预计算计入参数初始化。' not in prefix:
        prefix=prefix.replace('密码学计算采用单线程，使用 C++ 单调时钟计时；','四个 PBC 复现共用 Jacobian 多指数运算与公共固定基预计算，预计算计入参数初始化。密码学计算采用单线程，使用 C++ 单调时钟计时；')
    comm=r'''## 8.1 通信开销

记 $B_G$、$B_q$ 分别为群元素和标量的编码长度，$n$ 为属性总数，$d$ 为本次匹配的属性数，$u=n-d$，$m=\lceil\log_2\ell\rceil$。本次参数的群阶为 510 位，实际编码为 $B_G=66$ B、$B_q=64$ B；群编码包含 PBC 的 65 B 压缩点及 1 B 类型标记，用于区分单位元。以下固定 $\ell=64,n=16,d=4$，因此 $m=6,u=12$。各项长度均由原型的实际字节串核对。

表 2：密码学组件的输出大小。

| 组件 | 大小公式 | 字节数 |
| --- | --- | --- |
| 属性承诺 | $B_G$ | 66 B |
| 普通 Schnorr 签名 | $B_G+B_q$ | 130 B |
| 签发申请证明 | $3B_G+2B_q$ | 326 B |
| 二元 OoM 分支 | $8mB_G+(3m+1)B_q$ | 4,384 B |
| 消费共同开口分支 | $2B_G+(u+1)B_q$ | 964 B |
| 联合消费证明 | $(8m+2)B_G+(3m+u+2)B_q$ | 5,348 B |
| 转让证明，含内部辅助量 | $(8m+5)B_G+(3m+n+3)B_q$ | 5,866 B |

二元 OoM 的每个承诺包含两个群元素。消费开口分支包含两个首轮消息、一个随机数响应及 $u$ 个属性响应；转让开口分支包含三个首轮消息、两个随机数响应及 $n$ 个共享属性响应。两类联合证明分别与各自 OoM 使用共同的 Fiat–Shamir 挑战。转让证明还包含内部辅助量 $D_{\mathsf{tr}},U_{\mathsf{tr}}$。

表 3：本文主要消息大小。

| 消息 | 大小公式 | 字节数 |
| --- | --- | --- |
| 签发申请，不含核验资料 | $6B_G+(n+2)B_q$ | 1,548 B |
| 凭证 | $2B_G+B_q$ | 196 B |
| 联合消费证明 | $(8m+2)B_G+(3m+u+2)B_q$ | 5,348 B |
| 消费输出，不含候选列表 | $(8m+5)B_G+(3m+u+2)B_q$ | 5,546 B |
| 完整消费输出 | $(\ell+8m+5)B_G+(3m+u+2)B_q$ | 9,770 B |
| 完整转让公开输出 | $(\ell+8m+7)B_G+(3m+n+3)B_q$ | 10,222 B |

完整消费输出由 5,348 B 的联合证明、4,224 B 的候选列表及 198 B 的 $T,D,U$ 组成。完整转让输出包括相同长度的列表、旧标签 $T_A$、新承诺 $C_B$ 及 5,866 B 的转让证明。证明本体按 $\log_2\ell$ 增长，当前接口仍需传输线性大小的完整列表。

转让公开输出指提交账本的材料。按第 6 节，$A$ 还需私下向 $B$ 交付 $(C_A,o_A)$，其中 $o_A=(\mathbf a,r_A)$；这部分密码学字段另占 $B_G+(n+1)B_q=1,154$ B。连同公开提交，转让负载合计 11,376 B，不含保密信道封装及登记确认回执。

表 2—4 统计固定密码学字段，不含外部核验资料、服务请求及交易封装。原型另使用版本标识和向量长度构成自包含编码：签发申请额外增加 8 B，消费与转让各增加 12 B，对应完整编码分别为 1,556 B、9,782 B 和 10,234 B。

表 4：与 ACL 的理论通信开销比较。

| 比较项目 | ACL | 本文 |
| --- | --- | --- |
| 首次签发总通信 | $5B_G+(n+9)B_q$ | $10B_G+(n+4)B_q$ |
| 其中：用户与签发者通信 | $5B_G+(n+9)B_q$ | $8B_G+(n+3)B_q$ |
| 复用注册后的签发 | $3B_G+7B_q$ | — |
| 凭证 | $B_{\mathsf{msg}}+2B_G+6B_q$ | $2B_G+B_q$ |
| 属性开口证明分支 | $2B_G+(u+4)B_q$ | $2B_G+(u+1)B_q$ |
| 完整属性呈示 | $B_{\mathsf{msg}}+4B_G+(u+10)B_q$ | $(\ell+8m+5)B_G+(3m+u+2)B_q$ |

其中，$B_{\mathsf{msg}}$ 为 ACL 中被签名消息的长度。首次签发总通信包含本文另向账本提交的 $(C,\sigma_I)$。当前参数下，本文双边签发为 1,744 B，连同登记为 1,940 B；ACL 首次签发为 1,930 B。本文在属性开口分支少传输三个标量，凭证少 $B_{\mathsf{msg}}+5B_q$；含登记的首次签发总量略高于 ACL。完整呈示还受到 OoM 和候选列表的影响。

表 5：签发交互比较。'''
    # Raw strings above deliberately contain ordinary TeX backslashes.
    comm=comm.replace('\\\\','\\')
    rows=load_csv(DATA/'summary.csv')
    def row(s,op,n=16,ell=64):
        return next(r for r in rows if r['scheme']==s and r['operation']==op and int(r['n'])==n and int(r['ell'])==ell)
    def ms(s,op,n=16,ell=64):return f"{float(row(s,op,n,ell)['median_ms']):.2f}"
    def ci(s,op):
        r=row(s,op);return f"{float(r['ci95_low_ms']):.2f}–{float(r['ci95_high_ms']):.2f}"
    setup=load_csv(DATA/'setup.csv')
    param=statistics.median(float(r['ms']) for r in setup if r['component']=='public_parameters_and_key')
    context=float(next(r['ms'] for r in setup if r['component']=='pbc_context'))
    compute=r'''## 8.2 计算开销

图 1 固定 $n=16,d=4$，本文候选列表长度为 $\ell=64$，其余三个方案不使用该参数。四个方案采用相同群参数与编译设置。用户侧和签发者侧分别累计签发计算，ACL 首次签发包含注册和用户末尾验签。U-Prove 为相同 PBC 参数上的代数复现，未混入官方 P-256/Node 实现的耗时。Chan–Yuen 采用 Paillier 签发核心和单次 AND 属性出示；其签发未包含原文未具体实例化的加密相关证明，以 core 标注。

每次重复新签发一份凭证。本文的候选池包含 $\ell$ 个真实签发登记的承诺，生成阶段计入候选随机抽样、开口核对、重随机化及完整证明计算。验证包含登记查询、所需属性与证明核验，以及本地花费标签的原子查重和登记。消费与转让使用独立账本副本，副本准备和传输解码不计时；每个配置另检查一次真实编码往返。基线的查重是对比程序加入的状态操作，不表示各原方案均自带全局消费状态。

![图 1：主要算法的计算开销比较](assets/performance/figure_1_algorithm_costs_current.png)

图 1：主要算法计算开销。a，用户侧签发；b，签发者侧签发；c，呈示生成；d，呈示验证。柱高为 100 次技术重复的中位数，误差线为 95% 自助置信区间，各子图采用独立的线性纵轴。CY22 表示 Chan–Yuen，其签发结果仅为核心计算成本。

本文用户侧和签发者侧计算分别为 @OH@ ms、@OI@ ms，ACL 为 @AH@ ms、@AI@ ms，U-Prove 为 @UH@ ms、@UI@ ms。本文呈示生成耗时 @OS@ ms（95% CI：@OSCI@ ms），验证耗时 @OV@ ms（95% CI：@OVCI@ ms）；ACL 对应为 @AS@ ms、@AV@ ms，U-Prove 对应为 @US@ ms、@UV@ ms。表 5 所示的一次双边往返减少了签发消息交换，本文的呈示计算仍高于 ACL 和 U-Prove。

Chan–Yuen 的用户侧与签发者侧核心计算分别为 @CH@ ms、@CI@ ms，单次 AND 呈示生成与验证为 @CS@ ms、@CV@ ms。前两项不能作为完整签发成本。

在相同默认参数下，本文转让生成耗时 @OT@ ms（95% CI：@OTCI@ ms），转让验证耗时 @OTV@ ms（95% CI：@OTVCI@ ms）。转让验证包含旧标签花费与新承诺登记的本地原子提交；其余方案未在本次复现中实现对应转让操作。

初始化单独测量：PBC 上下文加载为 @CONTEXT@ ms，共用参数及密钥、本文新增参数初始化的中位数为 @PARAM@ ms。该测量包含共用辅助参数及公共固定基预计算；U-Prove 与 Chan–Yuen 的额外参数准备成本另存于 setup.csv。参数准备不计入逐次签发或呈示，固定曲线参数文件的离线生成亦不计入日常签发。

![图 2：候选列表规模对消费和转让计算开销的影响](assets/performance/figure_2_anonymity_set_current.png)

图 2：候选列表规模的影响。a，消费生成与验证；b，转让生成与验证。固定 $n=16,d=4$，虚线标出 $\ell=64$；默认点与图 1 使用同一组记录。点与误差线分别为 100 次技术重复的中位数与 95% 自助置信区间。

当 $\ell$ 从 16 增至 1,024 时，消费生成由 @S16@ ms 增至 @S1024@ ms，验证由 @V16@ ms 增至 @V1024@ ms；转让生成由 @T16@ ms 增至 @T1024@ ms，转让验证由 @TV16@ ms 增至 @TV1024@ ms。成员证明虽具有对数长度，生成与验证仍需处理候选列表，不能据证明长度推断计算也按对数增长。

属性规模实验取 $n\in\{4,8,16,32,64\}$、$d=n/4$，本文固定 $\ell=64$，结果见图 3。四个方案采用相同属性总数和匹配比例，不额外加入范围证明、撤销或克隆追踪。

![图 3：属性数量对呈示计算开销的影响](assets/performance/figure_3_attributes_current.png)

图 3：属性数量的影响。a，呈示生成；b，呈示验证。纵轴为对数刻度；点与误差线统计口径同图 2，$n=16$ 的记录与图 1 共用。

以上结果限于所列 PBC 实例和本机算法测量，不包含网络或共识耗时。不同方案的算法成本不表示安全模型或端到端安全位数相同；联合证明的完整安全论证仍需完成。源码、固定参数、12,600 条逐次耗时、实际编码长度及 LaTeX 图源均随实验仓库保存。
'''.replace('\\\\','\\')
    vals={}
    for prefix_,s in [('O','OTAC'),('A','ACL'),('U','UPROVE'),('C','CY22')]:
        for suffix,op in [('H','holder_issue'),('I','issuer_issue'),('S','show'),('V','verify')]:vals[prefix_+suffix]=ms(s,op)
    vals.update(OSCI=ci('OTAC','show'),OVCI=ci('OTAC','verify'),OT=ms('OTAC','transfer'),OTV=ms('OTAC','verify_transfer'),
                OTCI=ci('OTAC','transfer'),OTVCI=ci('OTAC','verify_transfer'),CONTEXT=f'{context:.2f}',PARAM=f'{param:.2f}')
    for suffix,op in [('S','show'),('V','verify'),('T','transfer'),('TV','verify_transfer')]:
        for ell in (16,1024):vals[suffix+str(ell)]=ms('OTAC',op,ell=ell)
    for key,value in vals.items():compute=compute.replace('@'+key+'@',value)
    assert '@' not in compute
    updated=prefix+comm+rounds+'## 8.2 计算开销'+compute.split('## 8.2 计算开销',1)[1]
    # Avoid replacing a user edit made while this script was preparing output.
    assert DOC.read_bytes()==old,'Manuscript changed during preparation; reread before writing'
    DOC.write_text(updated,encoding='utf-8',newline='\n')
    (DATA/'paper_integration.json').write_text(json.dumps(dict(
        chapter=str(DOC),sha256=hashlib.sha256(DOC.read_bytes()).hexdigest(),
        section_changed=8,other_chapters_modified=False,issuance_interaction_table_preserved=True),indent=2)+'\n',encoding='utf-8')
    print(DOC)


if __name__=='__main__':main()
