"""Check final manuscript images, PDF fonts and measured-source provenance."""
from pathlib import Path
import argparse
import json
import re
import subprocess
import fitz
from PIL import Image,ImageStat

from figure_support import ROOT, sha
from integrate_figures import STEMS, UTILIZATION_STEM


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reviewed", action="store_true", help="Record completed visual inspection")
    parser.add_argument('--directory',type=Path,default=ROOT/'results/current')
    parser.add_argument('--figures-dir',type=Path,default=ROOT/'figures/current')
    parser.add_argument('--utilization-dir',type=Path,default=ROOT/'results/utilization')
    parser.add_argument('--figure-suffix',default='_current')
    args=parser.parse_args()
    data,fig,utilization=args.directory,args.figures_dir,args.utilization_dir
    meta=json.loads((data/'environment.json').read_text(encoding='utf-8'))
    qa=json.loads((data/'qa.json').read_text(encoding='utf-8'))
    assert meta['complete'] and qa['passed']
    assert sha(data/'raw_timings.csv')==meta['raw_sha256']
    plotted=json.loads((fig/'data_audit.json').read_text(encoding='utf-8'))
    assert meta['raw_sha256'] in plotted['source_sha256'].values()
    assert qa['rows']==plotted['raw_rows']
    utilization_meta=json.loads((utilization/'environment.json').read_text(encoding='utf-8'))
    assert utilization_meta['complete']
    assert sha(utilization/'raw_timings.csv')==utilization_meta['raw_sha256']
    for name,digest in meta['source_sha256'].items():
        assert sha(ROOT/name)==digest,name

    construction=ROOT.parent/'中文稿/06_详细构造.md'
    if construction.exists():
        assert sha(construction)==meta['construction_sha256']
    doc=ROOT.parent/'中文稿/08_性能分析与实验评估.md'
    text=doc.read_text(encoding='utf-8') if doc.exists() else ''
    paths=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text) if text else []
    expected=[(fig,stem,stem+args.figure_suffix+'.png') for stem in STEMS]
    expected.append((utilization,UTILIZATION_STEM,UTILIZATION_STEM+'.png'))
    audit=[]
    for folder,stem,filename in expected:
        source=folder/(stem+'.png')
        pdf=folder/(stem+'.pdf')
        if text:
            matching=[rel for rel in paths if Path(rel).name==filename]
            assert len(matching)==1,filename
            image_path=doc.parent/matching[0]
            assert sha(image_path)==sha(source),image_path
            assert sha(image_path.with_suffix('.pdf'))==sha(pdf),image_path.with_suffix('.pdf')
        with fitz.open(pdf) as d:
            assert len(d)==1 and len(d[0].get_text().strip())>20
            page=d[0]
            width_mm=page.rect.width*25.4/72
            height_mm=page.rect.height*25.4/72
            for block in page.get_text('blocks'):
                assert block[0]>=-1 and block[1]>=-1 and block[2]<=page.rect.width+1 and block[3]<=page.rect.height+1, 'Clipped PDF text'
        with Image.open(source) as image:
            im=image.convert('RGB')
            assert im.width>1500 and min(ImageStat.Stat(im).stddev)>5
            png_pixels=[im.width,im.height]
        fonts=subprocess.check_output(['pdffonts',str(pdf)],text=True,stderr=subprocess.DEVNULL)
        (folder/(stem+'-fonts.txt')).write_text(fonts,encoding='utf-8')
        fontrows=fonts.strip().splitlines()[2:];assert fontrows and all(r.split()[-5]=='yes' for r in fontrows)
        report=folder/(stem+'-visual-qa.json')
        raw=json.loads(report.read_text()) if report.exists() else dict(status='not_run',issues=[])
        assert all(x['code'] in ('title_band_collision','text_plot_overlap') for x in raw['issues'])
        audit.append(dict(figure=stem,source=str(source.resolve()),pdf_sha256=sha(pdf),png_sha256=sha(source),
            width_mm=width_mm,height_mm=height_mm,png_pixels=png_pixels,selectable_text=True,fonts_embedded=True,
            raw_visual_qa_status=raw['status'],raw_visual_findings=len(raw['issues']),
            manually_accepted=args.reviewed))
    result=dict(passed=args.reviewed,revision=data.name,actual_manuscript_images_replaced=len(audit) if text else 0,
        current_crypto_sources_match_measured_hashes=True,construction_snapshot_unchanged=True,
        raw_rows=qa['rows'],communication_payload_and_wire_checks=qa['communication_equation_checks'],
        utilization=dict(raw_sha256=utilization_meta['raw_sha256'],
                         n=utilization_meta['n'],d=utilization_meta['d'],ell=utilization_meta['ell'],
                         paired_batches=utilization_meta['paired_batches']),
        figures=audit,renderer='XeLaTeX/PGFPlots; PDF-derived PNG at 300 dpi',
        automated_visual_check='Raw checker reports retained; not described as automated passes',
        limitations=['Local state adapter; no network/consensus timing','CY22 issuance remains core-only','No full security-proof or security-equivalence claim'])
    (fig/'final_qa.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    (data/'final_qa.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    render_path=fig/'render_audit.json'
    record=json.loads(render_path.read_text()) if render_path.exists() else dict(engine='XeLaTeX')
    record.update(renderer=result['renderer'],figures=audit[:-1])
    render_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed=args.reviewed,figures=len(audit),rows=qa['rows'],
                          size_checks=qa['communication_equation_checks'],paper_images_current=bool(text))))


if __name__=='__main__':main()
