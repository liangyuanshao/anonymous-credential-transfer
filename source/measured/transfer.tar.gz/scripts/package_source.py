"""Preserve the measured native sources byte-for-byte, including line endings."""
from pathlib import Path
import argparse
import json
import zipfile

from figure_support import ROOT, sha


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=ROOT/'results/current')
    data=parser.parse_args().directory
    meta=json.loads((data/'environment.json').read_text(encoding='utf-8'))
    assert meta['complete']
    assert sha(data/'raw_timings.csv')==meta['raw_sha256']
    files={ROOT/p for p in meta['source_sha256']}
    for name,digest in meta['source_sha256'].items():
        assert sha(ROOT/name)==digest,('source changed',name)
    files.update((ROOT/'baselines').glob('*/main.cpp'))
    files.update((ROOT/'tests').glob('*.cpp'))
    files.update((ROOT/'tests').glob('*.hpp'))
    files.update((ROOT/'scripts').glob('*.py'))
    files.update(ROOT/p for p in ('scripts/bootstrap.ps1','scripts/bootstrap.sh','README.md','LICENSE','requirements.txt','requirements-qa.txt'))
    files.update((ROOT/'docs').glob('*.md'))
    path=data/'measured-source.zip'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files):z.write(p,p.relative_to(ROOT).as_posix())
        z.writestr('MEASUREMENT_SOURCE_MANIFEST.json',json.dumps(dict(
            source_sha256=meta['source_sha256'],command=meta['command'],libraries=meta['libraries'],
            purpose='Exact measured sources; original file bytes and line endings are preserved. PBC dependency is pinned by bootstrap SHA256.'),indent=2))
    record=dict(file=path.name,bytes=path.stat().st_size,sha256=sha(path),native_source_hashes_verified=True)
    (data/'source_archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record,indent=2))


if __name__=='__main__':main()
