"""Measure complete issuance cohorts and actual one-time consumption prefixes."""
import argparse
import datetime
import json
import os
import platform
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from run_experiments import ROOT, sha, sources
from benchmark_config import DEFAULT_ELL, DEFAULT_N, DEFAULT_D


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results/utilization")
    parser.add_argument("--batches", type=int, default=24)
    parser.add_argument("--mode", choices=("legacy", "first-v2"), default="legacy")
    parser.add_argument("--attributes", type=int, choices=(16, 32))
    parser.add_argument("--binary", type=Path, help="Path to the utilization benchmark executable")
    parser.add_argument("--info-binary", type=Path, help="Path to credential_bench for parameter metadata")
    args = parser.parse_args()
    if args.batches < 6 or args.batches % 6:
        parser.error("choose a positive multiple of six for balanced execution order")
    first_v2 = args.mode == "first-v2"
    if first_v2 != (args.attributes is not None):
        parser.error("--attributes 16 or 32 is required in first-v2 mode and reserved for that mode")
    output = args.output.resolve()
    if output.exists():
        parser.error("choose a fresh output directory")

    default_executable = ROOT / "build-native/utilization_bench.exe"
    if os.name != "nt" or not default_executable.is_file():
        default_executable = ROOT / "build/utilization_bench"
    executable = args.binary.resolve() if args.binary else default_executable
    if not executable.is_file():
        parser.error("build utilization_bench before measuring")
    env = dict(os.environ)
    if os.name == "nt":
        env["PATH"] = r"C:\Strawberry\c\bin" + os.pathsep + env["PATH"]
    default_info = executable.with_name("credential_bench.exe" if os.name == "nt" else "credential_bench")
    info = args.info_binary.resolve() if args.info_binary else default_info
    if not info.is_file():
        parser.error("build credential_bench or provide --info-binary for parameter metadata")
    native = json.loads(subprocess.check_output(
        [str(info), "info", "parameters/type-f.param"], cwd=ROOT, env=env, text=True))
    before = sources()
    before["scripts/run_utilization.py"] = sha(Path(__file__))
    command = [str(executable), "parameters/type-f.param", str(args.batches)]
    if first_v2:
        command.extend((args.mode, str(args.attributes)))
    record = {
        "complete": False,
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "compiler": subprocess.check_output(["g++", "--version"], env=env, text=True).splitlines()[0],
        "build": "-O3; C++17" if args.binary else "CMake Release; -O3; C++17",
        "libraries": {"PBC": native["pbc"], "GMP": native["gmp_runtime"]},
        "native_parameters": native,
        "command": command,
        "source_sha256": before,
        "binary_sha256": sha(executable),
        "paired_batches": args.batches, "warmup_batches": 3,
        "credentials_per_batch": 64, "ell": DEFAULT_ELL,
        "n": args.attributes if first_v2 else DEFAULT_N, "d": DEFAULT_D,
        "issuance_mode": args.mode,
        "schemes": ["OTAC", "ACL", "UPROVE"],
        "order_seed": 20261107,
        "measurement": "Serial local calls using steady_clock; actual issuance, admission and distinct one-time uses",
        "acl": "One first registration per new holder; registration and check recorded separately",
        "practical_margin_pct": 10,
    }
    if os.name == "nt":
        record["hardware"] = json.loads(subprocess.check_output([
            "powershell", "-NoProfile", "-Command",
            "$p=Get-CimInstance Win32_Processor; $c=Get-CimInstance Win32_ComputerSystem; "
            "@{cpu=$p.Name;total_memory_bytes=$c.TotalPhysicalMemory}|ConvertTo-Json -Compress"
        ], encoding="utf-8"))
    elif platform.system() == "Linux":
        cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
                   if line.startswith(("model name", "Hardware")))
        memory_kib = int(Path("/proc/meminfo").read_text().splitlines()[0].split()[1])
        record["hardware"] = {"cpu": cpu, "total_memory_bytes": memory_kib * 1024}
        record["cpu_affinity"] = sorted(os.sched_getaffinity(0))
        record["distribution"] = platform.freedesktop_os_release()["PRETTY_NAME"]
    output.mkdir(parents=True)
    manifest = output / "environment.json"
    manifest.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    raw = output / "raw_timings.csv"
    with raw.open("x", encoding="utf-8", newline="") as rows, (output / "run.log").open("x", encoding="utf-8") as log:
        with subprocess.Popen(command, cwd=ROOT, env=env, stdout=rows, stderr=subprocess.PIPE,
                              text=True, encoding="utf-8", errors="replace") as run:
            for line in run.stderr:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
            if run.wait() != 0:
                raise RuntimeError("Native workload did not complete")
    if any(sha(ROOT / name) != digest for name, digest in before.items()) or sha(executable) != record["binary_sha256"]:
        raise RuntimeError("Native source or executable changed during the run")
    with ZipFile(output / "measured-source.zip", "x", ZIP_DEFLATED) as archive:
        for name in before:
            archive.write(ROOT / name, name)
    record.update(complete=True, raw_sha256=sha(raw),
                  completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    manifest.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(f"Saved measured workload to {output}")


if __name__ == "__main__":
    main()
